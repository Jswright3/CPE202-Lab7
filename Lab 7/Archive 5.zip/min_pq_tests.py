"""CPE202
John Wright
Lab 7
"""
import unittest
from min_pq import MinPQ

class MyTest(unittest.TestCase):
   def test_insert(self):
       heap = MinPQ()
       heap.insert(5)
       heap.insert(2)
       heap.insert(6)
       heap.insert(3)
       heap.insert(1)
       print(heap.arr)




if __name__ == '__main__':
   unittest.main()
