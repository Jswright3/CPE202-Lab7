"""CPE202
John Wright
Lab 7
"""
import unittest
from min_pq import MinPQ

class MyTest(unittest.TestCase):


if __name__ == '__main__':
   unittest.main()
